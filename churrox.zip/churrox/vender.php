<?php
$cantidad= $_POST["txt_cantidad"];
$tipo= $_POST["tipo"];
$subtotal=0;
if($cantidad <=0 )
{
    echo "ha digitado un valor incorrecto";
    exit;
}
if($tipo==1)
{
    $costo=3000;
}
if($tipo==2)
{
    $costo=3500;
}
if($tipo==3)
{
    $costo=4000;
}
$total= $cantidad * $costo;
if($total >=50000)
{
    $subtotal= $total - ($total*0.15);
echo $subtotal;
}else{
    echo $total;
}


?>


